package com.boomarrows.registry;

import com.boomarrows.BoomArrowsMod;
import com.boomarrows.entity.FireArrowEntity;
import com.boomarrows.entity.SnowArrowEntity;
import com.boomarrows.entity.TntArrowEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModEntities {
    public static final EntityType<TntArrowEntity> TNT_ARROW = register("tnt_arrow",
            FabricEntityTypeBuilder.<TntArrowEntity>create(SpawnGroup.MISC, TntArrowEntity::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f)).trackRangeBlocks(4).trackedUpdateRate(20).build());

    public static final EntityType<SnowArrowEntity> SNOW_ARROW = register("snow_arrow",
            FabricEntityTypeBuilder.<SnowArrowEntity>create(SpawnGroup.MISC, SnowArrowEntity::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f)).trackRangeBlocks(4).trackedUpdateRate(20).build());

    public static final EntityType<FireArrowEntity> FIRE_ARROW = register("fire_arrow",
            FabricEntityTypeBuilder.<FireArrowEntity>create(SpawnGroup.MISC, FireArrowEntity::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f)).trackRangeBlocks(4).trackedUpdateRate(20).build());

    private static <T extends Entity> EntityType<T> register(String name, EntityType<T> type) {
        return Registry.register(Registries.ENTITY_TYPE, BoomArrowsMod.id(name), type);
    }

    public static void register() {
        // Appeler cette methode force le chargement de la classe.
    }
}
