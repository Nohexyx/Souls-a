package com.boomarrows.registry;

import com.boomarrows.BoomArrowsMod;
import com.boomarrows.entity.FireArrowEntity;
import com.boomarrows.entity.SnowArrowEntity;
import com.boomarrows.entity.TntArrowEntity;
import com.boomarrows.item.ExplosiveArrowItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModItems {
    public static final Item TNT_ARROW = register("tnt_arrow",
            new ExplosiveArrowItem(new Item.Settings(), TntArrowEntity::new));
    public static final Item SNOW_ARROW = register("snow_arrow",
            new ExplosiveArrowItem(new Item.Settings(), SnowArrowEntity::new));
    public static final Item FIRE_ARROW = register("fire_arrow",
            new ExplosiveArrowItem(new Item.Settings(), FireArrowEntity::new));

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, BoomArrowsMod.id(name), item);
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(TNT_ARROW);
            entries.add(SNOW_ARROW);
            entries.add(FIRE_ARROW);
        });
    }
}
