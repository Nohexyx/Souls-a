package com.boomarrows.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ArrowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** Munition d'arc qui cree notre propre fleche explosive au lieu d'une fleche normale. */
public class ExplosiveArrowItem extends ArrowItem {

    @FunctionalInterface
    public interface Factory {
        PersistentProjectileEntity create(World world, LivingEntity owner, ItemStack stack, @Nullable ItemStack shotFrom);
    }

    private final Factory factory;

    public ExplosiveArrowItem(Settings settings, Factory factory) {
        super(settings);
        this.factory = factory;
    }

    @Override
    public PersistentProjectileEntity createArrow(World world, ItemStack stack, LivingEntity shooter,
                                                  @Nullable ItemStack shotFrom) {
        return this.factory.create(world, shooter, stack.copyWithCount(1), shotFrom);
    }
}
