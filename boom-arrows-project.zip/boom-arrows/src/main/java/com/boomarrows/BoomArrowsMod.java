package com.boomarrows;

import com.boomarrows.registry.ModEntities;
import com.boomarrows.registry.ModItems;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

public class BoomArrowsMod implements ModInitializer {
    public static final String MOD_ID = "boom_arrows";

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModEntities.register();
        ModItems.register();
    }
}
