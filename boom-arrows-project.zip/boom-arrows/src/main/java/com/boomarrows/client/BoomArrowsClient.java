package com.boomarrows.client;

import com.boomarrows.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class BoomArrowsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.TNT_ARROW, ExplosiveArrowRenderer::new);
        EntityRendererRegistry.register(ModEntities.SNOW_ARROW, ExplosiveArrowRenderer::new);
        EntityRendererRegistry.register(ModEntities.FIRE_ARROW, ExplosiveArrowRenderer::new);
    }
}
