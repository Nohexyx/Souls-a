package com.boomarrows.client;

import com.boomarrows.entity.ExplosiveArrowEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.ProjectileEntityRenderer;
import net.minecraft.util.Identifier;

public class ExplosiveArrowRenderer extends ProjectileEntityRenderer<ExplosiveArrowEntity> {
    public ExplosiveArrowRenderer(EntityRendererFactory.Context context) {
        super(context);
    }

    @Override
    public Identifier getTexture(ExplosiveArrowEntity entity) {
        return entity.getArrowTexture();
    }
}
