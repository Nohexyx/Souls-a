package com.boomarrows.entity;

import com.boomarrows.BoomArrowsMod;
import com.boomarrows.registry.ModEntities;
import com.boomarrows.registry.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** Fleche charge de feu : petite explosion qui allume des feux et enflamme les creatures proches. */
public class FireArrowEntity extends ExplosiveArrowEntity {
    private static final Identifier TEXTURE = BoomArrowsMod.id("textures/entity/fire_arrow.png");

    public FireArrowEntity(EntityType<? extends FireArrowEntity> type, World world) {
        super(type, world);
    }

    public FireArrowEntity(World world, LivingEntity owner, ItemStack stack, @Nullable ItemStack shotFrom) {
        super(ModEntities.FIRE_ARROW, owner, world, stack, shotFrom);
    }

    @Override
    protected ItemStack getDefaultItemStack() {
        return new ItemStack(ModItems.FIRE_ARROW);
    }

    @Override
    public Identifier getArrowTexture() {
        return TEXTURE;
    }

    @Override
    protected void explode() {
        World world = this.getWorld();
        world.createExplosion(this, this.getX(), this.getY(), this.getZ(), 1.6f, true,
                World.ExplosionSourceType.MOB);
        if (world instanceof ServerWorld serverWorld) {
            serverWorld.spawnParticles(ParticleTypes.FLAME, this.getX(), this.getY(), this.getZ(),
                    50, 1.0, 0.6, 1.0, 0.06);
        }
        Box area = this.getBoundingBox().expand(4.0);
        for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, area, e -> e != this.getOwner())) {
            target.setOnFireFor(6);
        }
    }
}
