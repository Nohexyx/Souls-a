package com.boomarrows.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** Base commune : la fleche explose au premier impact (bloc ou creature), puis disparait. */
public abstract class ExplosiveArrowEntity extends PersistentProjectileEntity {
    private boolean exploded = false;

    protected ExplosiveArrowEntity(EntityType<? extends ExplosiveArrowEntity> type, World world) {
        super(type, world);
    }

    protected ExplosiveArrowEntity(EntityType<? extends ExplosiveArrowEntity> type, LivingEntity owner,
                                   World world, ItemStack stack, @Nullable ItemStack shotFrom) {
        super(type, owner, world, stack, shotFrom);
    }

    /** Texture utilisee par le rendu. */
    public abstract Identifier getArrowTexture();

    /** Effet de l'explosion (appele cote serveur uniquement). */
    protected abstract void explode();

    @Override
    protected void onEntityHit(EntityHitResult result) {
        super.onEntityHit(result);
        detonate();
    }

    @Override
    protected void onBlockHit(BlockHitResult result) {
        super.onBlockHit(result);
        detonate();
    }

    private void detonate() {
        if (this.getWorld().isClient || this.exploded) {
            return;
        }
        this.exploded = true;
        this.explode();
        this.discard();
    }
}
