package com.boomarrows.entity;

import com.boomarrows.BoomArrowsMod;
import com.boomarrows.registry.ModEntities;
import com.boomarrows.registry.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/** Fleche TNT : vraie explosion, qui detruit les blocs comme une TNT. */
public class TntArrowEntity extends ExplosiveArrowEntity {
    private static final Identifier TEXTURE = BoomArrowsMod.id("textures/entity/tnt_arrow.png");

    public TntArrowEntity(EntityType<? extends TntArrowEntity> type, World world) {
        super(type, world);
    }

    public TntArrowEntity(World world, LivingEntity owner, ItemStack stack, @Nullable ItemStack shotFrom) {
        super(ModEntities.TNT_ARROW, owner, world, stack, shotFrom);
    }

    @Override
    protected ItemStack getDefaultItemStack() {
        return new ItemStack(ModItems.TNT_ARROW);
    }

    @Override
    public Identifier getArrowTexture() {
        return TEXTURE;
    }

    @Override
    protected void explode() {
        this.getWorld().createExplosion(this, this.getX(), this.getY(), this.getZ(), 3.0f, false,
                World.ExplosionSourceType.TNT);
    }
}
