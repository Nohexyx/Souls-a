package com.boomarrows.entity;

import com.boomarrows.BoomArrowsMod;
import com.boomarrows.registry.ModEntities;
import com.boomarrows.registry.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Fleche boule de neige : eclatement de givre. Aucun degat aux blocs ;
 * repousse, ralentit et gele les creatures proches, et eteint les flammes.
 */
public class SnowArrowEntity extends ExplosiveArrowEntity {
    private static final Identifier TEXTURE = BoomArrowsMod.id("textures/entity/snow_arrow.png");

    public SnowArrowEntity(EntityType<? extends SnowArrowEntity> type, World world) {
        super(type, world);
    }

    public SnowArrowEntity(World world, LivingEntity owner, ItemStack stack, @Nullable ItemStack shotFrom) {
        super(ModEntities.SNOW_ARROW, owner, world, stack, shotFrom);
    }

    @Override
    protected ItemStack getDefaultItemStack() {
        return new ItemStack(ModItems.SNOW_ARROW);
    }

    @Override
    public Identifier getArrowTexture() {
        return TEXTURE;
    }

    @Override
    protected void explode() {
        World world = this.getWorld();
        double x = this.getX();
        double y = this.getY();
        double z = this.getZ();
        if (world instanceof ServerWorld serverWorld) {
            serverWorld.spawnParticles(ParticleTypes.SNOWFLAKE, x, y, z, 90, 1.3, 0.8, 1.3, 0.08);
            serverWorld.spawnParticles(ParticleTypes.CLOUD, x, y, z, 25, 0.7, 0.4, 0.7, 0.05);
        }
        world.playSound(null, x, y, z, SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.NEUTRAL, 1.0f, 1.4f);
        world.playSound(null, x, y, z, SoundEvents.BLOCK_SNOW_BREAK, SoundCategory.NEUTRAL, 1.2f, 0.8f);

        Box area = this.getBoundingBox().expand(4.0);
        for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, area, e -> e != this.getOwner())) {
            target.takeKnockback(0.9, x - target.getX(), z - target.getZ());
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 120, 2));
            target.setFrozenTicks(160);
            target.extinguish();
        }
    }
}
