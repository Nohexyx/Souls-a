package com.example.blockchain.mixin;

import com.example.blockchain.BlockChainMod;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;

@Mixin(Block.class)
public class BlockMixin {

    @Inject(
        method = "getDroppedStacks(Lnet/minecraft/block/BlockState;Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/entity/BlockEntity;Lnet/minecraft/entity/Entity;Lnet/minecraft/item/ItemStack;)Ljava/util/List;",
        at = @At("RETURN"),
        cancellable = true
    )
    private static void blockchain$replaceDrops(BlockState state, ServerWorld world, BlockPos pos,
                                                BlockEntity be, Entity entity, ItemStack tool,
                                                CallbackInfoReturnable<List<ItemStack>> cir) {
        List<ItemStack> original = cir.getReturnValue();
        // Pas de drop d'origine (mauvais outil, verre sans Silk Touch...) -> on respecte ça
        if (original == null || original.isEmpty()) return;

        Item replacement = BlockChainMod.getReplacement(state.getBlock());
        if (replacement == null) return;

        int count = 0;
        for (ItemStack s : original) count += s.getCount();
        count = Math.max(1, Math.min(count, replacement.getMaxCount()));

        List<ItemStack> result = new ArrayList<>();
        result.add(new ItemStack(replacement, count));
        cir.setReturnValue(result);
    }
}
