package com.example.blockchain;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class BlockChainMod implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("blockchain");

    /** Bloc cassé -> item droppé à la place. Recalculé à chaque démarrage de monde (seed du monde). */
    private static volatile Map<Block, Item> mapping = null;

    /** Blocs qu'on ne veut pas donner au joueur. */
    private static final Set<String> BANNED = Set.of(
            "minecraft:air", "minecraft:bedrock", "minecraft:barrier", "minecraft:light",
            "minecraft:command_block", "minecraft:chain_command_block", "minecraft:repeating_command_block",
            "minecraft:structure_block", "minecraft:structure_void", "minecraft:jigsaw",
            "minecraft:end_portal_frame", "minecraft:spawner", "minecraft:reinforced_deepslate",
            "minecraft:test_block", "minecraft:test_instance_block"
    );

    @Override
    public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> buildMapping(server.getOverworld().getSeed()));
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> mapping = null);
    }

    public static Item getReplacement(Block block) {
        Map<Block, Item> m = mapping;
        return m == null ? null : m.get(block);
    }

    private static void buildMapping(long seed) {
        List<Block> sources = new ArrayList<>();
        List<Item> targets = new ArrayList<>();

        for (Block block : Registries.BLOCK) {
            String id = Registries.BLOCK.getId(block).toString();
            if (id.equals("minecraft:air") || id.endsWith("_air")) continue;
            sources.add(block);
            Item item = block.asItem();
            if (item instanceof BlockItem && !BANNED.contains(id)) targets.add(item);
        }

        // Ordre stable pour que la seed donne toujours le même résultat
        sources.sort(Comparator.comparing(b -> Registries.BLOCK.getId(b).toString()));
        targets.sort(Comparator.comparing(i -> Registries.ITEM.getId(i).toString()));

        Collections.shuffle(targets, new Random(seed));

        Map<Block, Item> result = new HashMap<>();
        for (int i = 0; i < sources.size(); i++) {
            Block src = sources.get(i);
            Item dst = targets.get(i % targets.size());
            // Évite qu'un bloc donne lui-même
            if (dst == src.asItem()) dst = targets.get((i + 1) % targets.size());
            result.put(src, dst);
        }
        mapping = result;
        LOGGER.info("Block Chain: {} blocs mappés (seed {})", result.size(), seed);
    }
}
