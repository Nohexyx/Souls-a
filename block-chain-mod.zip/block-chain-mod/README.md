# Block Chain (Fabric 1.21.1)
Casser un bloc -> il drop un autre bloc (mapping aléatoire fixé par la seed du monde). Casser celui-ci -> encore un autre, etc.

Build : `gradle wrapper` (une fois, Gradle 8.10+), puis `./gradlew build` (Java 21).
Le jar est dans build/libs/. Nécessite Fabric API.
