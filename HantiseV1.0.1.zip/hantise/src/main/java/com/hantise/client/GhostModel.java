package com.hantise.client;

import com.hantise.HantiseMod;
import com.hantise.entity.GhostEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * Modele d'ame : tete arrondie (cube aux aretes coupees), corps d'un seul bloc
 * et bas du drap decoupe en lambeaux qui ondulent.
 */
public class GhostModel extends SinglePartEntityModel<GhostEntity> {
    public static final EntityModelLayer LAYER = new EntityModelLayer(HantiseMod.id("ghost"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart[] hems = new ModelPart[5];

    public GhostModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        for (int i = 0; i < hems.length; i++) {
            this.hems[i] = root.getChild("hem" + i);
        }
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();

        // Tete : cube aux aretes coupees (3 boites qui se recouvrent)
        root.addChild("head", ModelPartBuilder.create()
                        .uv(0, 0).cuboid(-4, -7, -3, 8, 6, 6)
                        .uv(28, 0).cuboid(-3, -8, -3, 6, 8, 6)
                        .uv(0, 14).cuboid(-3, -7, -4, 6, 6, 8),
                ModelTransform.pivot(0, 4, 0));

        // Corps : un seul bloc haut (pas d'anneaux)
        root.addChild("body", ModelPartBuilder.create()
                        .uv(0, 30).cuboid(-4, 0, -3, 8, 10, 6),
                ModelTransform.pivot(0, 4, 0));

        // Bas du drap : 5 lambeaux de longueurs differentes, qui ondulent
        float[] lengths = {7, 9, 6, 9, 8};
        int[] us = {0, 12, 24, 36, 46};
        for (int i = 0; i < 5; i++) {
            root.addChild("hem" + i, ModelPartBuilder.create()
                            .uv(us[i], 48).cuboid(-1, 0, -3.5f, 2, lengths[i], 7),
                    ModelTransform.pivot(-4 + 2 * i, 14, 0));
        }

        // Bras fins et longs, ecartes vers l'exterieur
        root.addChild("right_arm", ModelPartBuilder.create().uv(40, 30).cuboid(-1, 0, -1, 2, 10, 2),
                ModelTransform.of(-5.2f, 6, 0, 0, 0, 0.25f));
        root.addChild("left_arm", ModelPartBuilder.create().uv(40, 30).cuboid(-1, 0, -1, 2, 10, 2),
                ModelTransform.of(5.2f, 6, 0, 0, 0, -0.25f));

        return TexturedModelData.of(data, 64, 64);
    }

    @Override
    public void setAngles(GhostEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        // Flottement doux
        this.root.pivotY = MathHelper.sin(animationProgress * 0.08f) * 1.2f - 1.0f;
        // La tete suit le regard
        this.head.yaw = headYaw * 0.017453292f;
        this.head.pitch = headPitch * 0.017453292f;
        // Bras qui ondulent lentement
        float sway = MathHelper.sin(animationProgress * 0.09f) * 0.12f;
        this.rightArm.pitch = -0.25f + sway;
        this.leftArm.pitch = -0.25f - sway;
        // Lambeaux du bas : ondulent en decalage, comme du tissu
        for (int i = 0; i < hems.length; i++) {
            float phase = animationProgress * 0.12f + i * 0.9f;
            this.hems[i].pitch = MathHelper.sin(phase) * 0.14f + 0.05f;
            this.hems[i].roll = MathHelper.sin(phase * 0.7f + 1.3f) * 0.06f;
        }
    }

    @Override
    public ModelPart getPart() {
        return this.root;
    }
}
