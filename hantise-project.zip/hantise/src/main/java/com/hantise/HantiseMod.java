package com.hantise;

import com.hantise.registry.ModEntities;
import com.hantise.registry.ModItems;
import com.hantise.registry.ModSounds;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

public class HantiseMod implements ModInitializer {
    public static final String MOD_ID = "hantise";

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModSounds.register();
        ModEntities.register();
        ModItems.register();
    }
}
