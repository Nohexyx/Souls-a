package com.hantise.client;

import com.hantise.HantiseMod;
import com.hantise.entity.GhostEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

public class GhostEntityRenderer extends MobEntityRenderer<GhostEntity, GhostModel> {
    private static final Identifier TEXTURE = HantiseMod.id("textures/entity/ghost.png");

    public GhostEntityRenderer(EntityRendererFactory.Context context) {
        super(context, new GhostModel(context.getPart(GhostModel.LAYER)), 0.0f);
    }

    @Override
    public Identifier getTexture(GhostEntity entity) {
        return TEXTURE;
    }

    @Override
    protected RenderLayer getRenderLayer(GhostEntity entity, boolean showBody, boolean translucent, boolean showOutline) {
        // Pixels pleins ou troues (pas de semi-transparence) : on ne voit plus l'interieur.
        return RenderLayer.getEntityCutoutNoCull(TEXTURE);
    }

    @Override
    protected int getBlockLight(GhostEntity entity, BlockPos pos) {
        // Eclairage maximal : les yeux restent visibles meme dans le noir.
        return 15;
    }
}
