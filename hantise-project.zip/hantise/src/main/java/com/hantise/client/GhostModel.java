package com.hantise.client;

import com.hantise.HantiseMod;
import com.hantise.entity.GhostEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * Silhouette d'ombre : tete, torse mince, bras fins et bas effiloche en trois lambeaux.
 * Aucune boite ne recouvre une autre, donc rien ne transparait a l'interieur.
 */
public class GhostModel extends SinglePartEntityModel<GhostEntity> {
    public static final EntityModelLayer LAYER = new EntityModelLayer(HantiseMod.id("ghost"), "main");
    private static final int HEMS = 3;

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart[] hems = new ModelPart[HEMS];

    public GhostModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        for (int i = 0; i < HEMS; i++) {
            this.hems[i] = root.getChild("hem" + i);
        }
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();

        // Tete : une seule boite (visage = face avant, 6x7)
        root.addChild("head", ModelPartBuilder.create()
                        .uv(0, 0).cuboid(-3, -7, -2.5f, 6, 7, 5),
                ModelTransform.pivot(0, 4, 0));

        // Torse mince
        root.addChild("body", ModelPartBuilder.create()
                        .uv(24, 0).cuboid(-3, 0, -1.5f, 6, 10, 3),
                ModelTransform.pivot(0, 4, 0));

        // Bas effiloche : trois lambeaux de longueurs differentes
        float[] lengths = {6, 9, 5};
        for (int i = 0; i < HEMS; i++) {
            root.addChild("hem" + i, ModelPartBuilder.create()
                            .uv(i * 10, 16).cuboid(-1, 0, -1.5f, 2, lengths[i], 3),
                    ModelTransform.pivot(-2 + 2 * i, 14, 0));
        }

        // Bras fins et longs, pendants
        root.addChild("right_arm", ModelPartBuilder.create().uv(44, 0).cuboid(-1, 0, -1, 2, 12, 2),
                ModelTransform.of(-4.2f, 5.5f, 0, 0, 0, 0.1f));
        root.addChild("left_arm", ModelPartBuilder.create().uv(44, 0).cuboid(-1, 0, -1, 2, 12, 2),
                ModelTransform.of(4.2f, 5.5f, 0, 0, 0, -0.1f));

        return TexturedModelData.of(data, 64, 64);
    }

    @Override
    public void setAngles(GhostEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        // Flotte au-dessus du sol, tres lentement
        this.root.pivotY = MathHelper.sin(animationProgress * 0.07f) * 1.5f - 2.0f;
        this.head.yaw = headYaw * 0.017453292f;
        this.head.pitch = headPitch * 0.017453292f;
        float sway = MathHelper.sin(animationProgress * 0.08f) * 0.1f;
        this.rightArm.pitch = -0.1f + sway;
        this.leftArm.pitch = -0.1f - sway;
        for (int i = 0; i < HEMS; i++) {
            float phase = animationProgress * 0.1f + i * 1.1f;
            this.hems[i].pitch = MathHelper.sin(phase) * 0.12f + 0.04f;
            this.hems[i].roll = MathHelper.sin(phase * 0.7f + 1.3f) * 0.05f;
        }
    }

    @Override
    public ModelPart getPart() {
        return this.root;
    }
}
