package com.hantise.client;

import com.hantise.HantiseMod;
import com.hantise.entity.GhostEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * Modele d'ame : tete arrondie (cube aux aretes coupees) et corps en forme de drap
 * qui s'evase vers le bas. Les coins sont adoucis en croisant deux boites par couche.
 */
public class GhostModel extends SinglePartEntityModel<GhostEntity> {
    public static final EntityModelLayer LAYER = new EntityModelLayer(HantiseMod.id("ghost"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;

    public GhostModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
    }

    /** Une couche arrondie : deux boites croisees (coins coupes). */
    private static ModelPartBuilder layer(ModelPartBuilder b, int u, int v,
                                          float x, float y, float z, float w, float h, float d) {
        return b.uv(u, v).cuboid(x + 1, y, z, w - 2, h, d)
                .uv(u, v).cuboid(x, y, z + 1, w, h, d - 2);
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();

        // Tete : cube aux aretes coupees (3 boites qui se recouvrent)
        root.addChild("head", ModelPartBuilder.create()
                        .uv(0, 0).cuboid(-4, -7, -3, 8, 6, 6)
                        .uv(28, 0).cuboid(-3, -8, -3, 6, 8, 6)
                        .uv(0, 14).cuboid(-3, -7, -4, 6, 6, 8),
                ModelTransform.pivot(0, 4, 0));

        // Corps : drap qui s'evase vers le bas
        ModelPartBuilder body = ModelPartBuilder.create();
        layer(body, 0, 30, -3.5f, 0, -2.5f, 7, 5, 5);
        layer(body, 0, 40, -4.5f, 5, -3.5f, 9, 5, 7);
        layer(body, 0, 50, -5.5f, 10, -4.5f, 11, 5, 9);
        layer(body, 24, 50, -6f, 15, -5f, 12, 4, 10);
        root.addChild("body", body, ModelTransform.pivot(0, 4, 0));

        // Bras : deux moignons flottants, ecartes vers l'exterieur
        root.addChild("right_arm", ModelPartBuilder.create().uv(40, 30).cuboid(-1.5f, 0, -1.5f, 3, 8, 3),
                ModelTransform.of(-6.5f, 6, 0, 0, 0, 0.3f));
        root.addChild("left_arm", ModelPartBuilder.create().uv(40, 30).cuboid(-1.5f, 0, -1.5f, 3, 8, 3),
                ModelTransform.of(6.5f, 6, 0, 0, 0, -0.3f));

        return TexturedModelData.of(data, 64, 64);
    }

    @Override
    public void setAngles(GhostEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        // Flottement doux
        this.root.pivotY = MathHelper.sin(animationProgress * 0.08f) * 1.2f - 1.0f;
        // La tete suit le regard
        this.head.yaw = headYaw * 0.017453292f;
        this.head.pitch = headPitch * 0.017453292f;
        // Bras qui ondulent lentement
        float sway = MathHelper.sin(animationProgress * 0.09f) * 0.12f;
        this.rightArm.pitch = -0.25f + sway;
        this.leftArm.pitch = -0.25f - sway;
    }

    @Override
    public ModelPart getPart() {
        return this.root;
    }
}
