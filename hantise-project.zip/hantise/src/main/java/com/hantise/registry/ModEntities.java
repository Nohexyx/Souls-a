package com.hantise.registry;

import com.hantise.HantiseMod;
import com.hantise.entity.GhostEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModEntities {
    public static final EntityType<GhostEntity> GHOST = Registry.register(
            Registries.ENTITY_TYPE,
            HantiseMod.id("ghost"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, GhostEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.9f))
                    .trackRangeBlocks(64)
                    .build()
    );

    public static void register() {
        FabricDefaultAttributeRegistry.register(GHOST, GhostEntity.createGhostAttributes());
    }
}
