package com.hantise.registry;

import com.hantise.HantiseMod;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class ModSounds {
    public static final SoundEvent GHOST_WHISPER = register("ghost.whisper");

    private static SoundEvent register(String name) {
        Identifier id = HantiseMod.id(name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void register() {
        // Appeler cette methode force le chargement de la classe.
    }
}
