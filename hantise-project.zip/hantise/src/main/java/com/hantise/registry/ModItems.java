package com.hantise.registry;

import com.hantise.HantiseMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class ModItems {
    public static final Item GHOST_SPAWN_EGG = Registry.register(
            Registries.ITEM,
            HantiseMod.id("ghost_spawn_egg"),
            new SpawnEggItem(ModEntities.GHOST, 0xCFE8F0, 0x4A5A6A, new Item.Settings())
    );

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS)
                .register(entries -> entries.add(GHOST_SPAWN_EGG));
    }
}
